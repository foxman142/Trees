﻿using System;

namespace Trees
{
    class Program
    {
        static void Main(string[] args)
        {
            string root = "root";
            TreeNode<string> myTreeRoot = new TreeNode<string>(root);
            var first = myTreeRoot.AddChild("first child");
            var second = myTreeRoot.AddChild("second child");
            var grandChild = first.AddChild("first child's child");
        }
    }
}
